import { Component, ViewChild } from '@angular/core';
import { Platform, Nav } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { IngresarPage } from '../pages/ingresar/ingresar';
import { LecciNPage } from '../pages/lecci-n/lecci-n';
import { LasVocalesPage } from '../pages/las-vocales/las-vocales';
import { FrasesCortas2Page } from '../pages/frases-cortas2/frases-cortas2';
import { ConsonantesPage } from '../pages/consonantes/consonantes';
import { MPage } from '../pages/m/m';
import { MaPage } from '../pages/ma/ma';
import { PPage } from '../pages/p/p';
import { NPage } from '../pages/n/n';
import { LPage } from '../pages/l/l';


import { CloudTabDefaultPagePage } from '../pages/cloud-tab-default-page/cloud-tab-default-page';



@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) navCtrl: Nav;
    rootPage:any = CloudTabDefaultPagePage;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
    });
  }
  goToIngresar(params){
    if (!params) params = {};
    this.navCtrl.setRoot(IngresarPage);
  }goToLecciN(params){
    if (!params) params = {};
    this.navCtrl.setRoot(LecciNPage);
  }goToLasVocales(params){
    if (!params) params = {};
    this.navCtrl.setRoot(LasVocalesPage);
  }goToFrasesCortas2(params){
    if (!params) params = {};
    this.navCtrl.setRoot(FrasesCortas2Page);
  }goToConsonantes(params){
    if (!params) params = {};
    this.navCtrl.setRoot(ConsonantesPage);
  }goToM(params){
    if (!params) params = {};
    this.navCtrl.setRoot(MPage);
  }goToMa(params){
    if (!params) params = {};
    this.navCtrl.setRoot(MaPage);
  }goToP(params){
    if (!params) params = {};
    this.navCtrl.setRoot(PPage);
  }goToN(params){
    if (!params) params = {};
    this.navCtrl.setRoot(NPage);
  }goToL(params){
    if (!params) params = {};
    this.navCtrl.setRoot(LPage);
  }
}
