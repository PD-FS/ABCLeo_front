import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { CameraTabDefaultPagePage } from '../pages/camera-tab-default-page/camera-tab-default-page';
import { PatrocinadorPage } from '../pages/patrocinador/patrocinador';
import { CloudTabDefaultPagePage } from '../pages/cloud-tab-default-page/cloud-tab-default-page';
import { FrasesCortasPage } from '../pages/frases-cortas/frases-cortas';
import { IngresarPage } from '../pages/ingresar/ingresar';
import { LasVocalesPage } from '../pages/las-vocales/las-vocales';
import { LasVocales2Page } from '../pages/las-vocales2/las-vocales2';
import { LasVocales3Page } from '../pages/las-vocales3/las-vocales3';
import { LasVocales4Page } from '../pages/las-vocales4/las-vocales4';
import { LasVocales5Page } from '../pages/las-vocales5/las-vocales5';
import { ConsonantesPage } from '../pages/consonantes/consonantes';
import { MPage } from '../pages/m/m';
import { PPage } from '../pages/p/p';
import { NPage } from '../pages/n/n';
import { LPage } from '../pages/l/l';
import { FrasesCortas2Page } from '../pages/frases-cortas2/frases-cortas2';
import { LecciNPage } from '../pages/lecci-n/lecci-n';
import { MaPage } from '../pages/ma/ma';
import { JuegosPage } from '../pages/juegos/juegos';
import { SilabasTrabadasPage } from '../pages/silabas-trabadas/silabas-trabadas';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    CameraTabDefaultPagePage,
    PatrocinadorPage,
    CloudTabDefaultPagePage,
    FrasesCortasPage,
    IngresarPage,
    LasVocalesPage,
    LasVocales2Page,
    LasVocales3Page,
    LasVocales4Page,
    LasVocales5Page,
    ConsonantesPage,
    MPage,
    PPage,
    NPage,
    LPage,
    FrasesCortas2Page,
    LecciNPage,
    MaPage,
    JuegosPage,
    SilabasTrabadasPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    CameraTabDefaultPagePage,
    PatrocinadorPage,
    CloudTabDefaultPagePage,
    FrasesCortasPage,
    IngresarPage,
    LasVocalesPage,
    LasVocales2Page,
    LasVocales3Page,
    LasVocales4Page,
    LasVocales5Page,
    ConsonantesPage,
    MPage,
    PPage,
    NPage,
    LPage,
    FrasesCortas2Page,
    LecciNPage,
    MaPage,
    JuegosPage,
    SilabasTrabadasPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}