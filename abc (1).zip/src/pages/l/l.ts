import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-l',
  templateUrl: 'l.html'
})
export class LPage {

  constructor(public navCtrl: NavController) {
  }
  
}
