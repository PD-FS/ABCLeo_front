import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-n',
  templateUrl: 'n.html'
})
export class NPage {

  constructor(public navCtrl: NavController) {
  }
  
}
