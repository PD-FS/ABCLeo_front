import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MaPage } from '../ma/ma';

@Component({
  selector: 'page-m',
  templateUrl: 'm.html'
})
export class MPage {

  constructor(public navCtrl: NavController) {
  }
  goToMa(params){
    if (!params) params = {};
    this.navCtrl.push(MaPage);
  }
}
