import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-frases-cortas2',
  templateUrl: 'frases-cortas2.html'
})
export class FrasesCortas2Page {

  constructor(public navCtrl: NavController) {
  }
  
}
