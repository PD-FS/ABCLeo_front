import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-las-vocales',
  templateUrl: 'las-vocales.html'
})
export class LasVocalesPage {

  constructor(public navCtrl: NavController) {
  }
  
}
