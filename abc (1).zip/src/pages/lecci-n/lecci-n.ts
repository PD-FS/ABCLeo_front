import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LasVocalesPage } from '../las-vocales/las-vocales';
import { FrasesCortas2Page } from '../frases-cortas2/frases-cortas2';
import { ConsonantesPage } from '../consonantes/consonantes';
import { MPage } from '../m/m';
import { MaPage } from '../ma/ma';
import { PPage } from '../p/p';
import { NPage } from '../n/n';
import { LPage } from '../l/l';

@Component({
  selector: 'page-lecci-n',
  templateUrl: 'lecci-n.html'
})
export class LecciNPage {

  constructor(public navCtrl: NavController) {
  }
  goToLasVocales(params){
    if (!params) params = {};
    this.navCtrl.push(LasVocalesPage);
  }goToFrasesCortas2(params){
    if (!params) params = {};
    this.navCtrl.push(FrasesCortas2Page);
  }goToConsonantes(params){
    if (!params) params = {};
    this.navCtrl.push(ConsonantesPage);
  }goToM(params){
    if (!params) params = {};
    this.navCtrl.push(MPage);
  }goToMa(params){
    if (!params) params = {};
    this.navCtrl.push(MaPage);
  }goToP(params){
    if (!params) params = {};
    this.navCtrl.push(PPage);
  }goToN(params){
    if (!params) params = {};
    this.navCtrl.push(NPage);
  }goToL(params){
    if (!params) params = {};
    this.navCtrl.push(LPage);
  }
}
