import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-las-vocales5',
  templateUrl: 'las-vocales5.html'
})
export class LasVocales5Page {

  constructor(public navCtrl: NavController) {
  }
  
}
