import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-las-vocales2',
  templateUrl: 'las-vocales2.html'
})
export class LasVocales2Page {

  constructor(public navCtrl: NavController) {
  }
  
}
