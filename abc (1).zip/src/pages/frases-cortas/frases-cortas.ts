import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { IngresarPage } from '../ingresar/ingresar';
import { LecciNPage } from '../lecci-n/lecci-n';
import { LasVocalesPage } from '../las-vocales/las-vocales';
import { FrasesCortas2Page } from '../frases-cortas2/frases-cortas2';
import { ConsonantesPage } from '../consonantes/consonantes';
import { MPage } from '../m/m';
import { MaPage } from '../ma/ma';
import { PPage } from '../p/p';
import { NPage } from '../n/n';
import { LPage } from '../l/l';
import { IngresarPage } from '../ingresar/ingresar';
import { PatrocinadorPage } from '../patrocinador/patrocinador';

@Component({
  selector: 'page-frases-cortas',
  templateUrl: 'frases-cortas.html'
})
export class FrasesCortasPage {

  tab1Root: any = IngresarPage;
  tab2Root: any = PatrocinadorPage;
  constructor(public navCtrl: NavController) {
  }
  goToIngresar(params){
    if (!params) params = {};
    this.navCtrl.push(IngresarPage);
  }goToLecciN(params){
    if (!params) params = {};
    this.navCtrl.push(LecciNPage);
  }goToLasVocales(params){
    if (!params) params = {};
    this.navCtrl.push(LasVocalesPage);
  }goToFrasesCortas2(params){
    if (!params) params = {};
    this.navCtrl.push(FrasesCortas2Page);
  }goToConsonantes(params){
    if (!params) params = {};
    this.navCtrl.push(ConsonantesPage);
  }goToM(params){
    if (!params) params = {};
    this.navCtrl.push(MPage);
  }goToMa(params){
    if (!params) params = {};
    this.navCtrl.push(MaPage);
  }goToP(params){
    if (!params) params = {};
    this.navCtrl.push(PPage);
  }goToN(params){
    if (!params) params = {};
    this.navCtrl.push(NPage);
  }goToL(params){
    if (!params) params = {};
    this.navCtrl.push(LPage);
  }
}
