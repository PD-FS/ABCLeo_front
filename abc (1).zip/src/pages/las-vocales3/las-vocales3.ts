import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-las-vocales3',
  templateUrl: 'las-vocales3.html'
})
export class LasVocales3Page {

  constructor(public navCtrl: NavController) {
  }
  
}
