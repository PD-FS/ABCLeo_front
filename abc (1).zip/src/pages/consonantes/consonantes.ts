import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MPage } from '../m/m';
import { MaPage } from '../ma/ma';
import { PPage } from '../p/p';
import { NPage } from '../n/n';
import { LPage } from '../l/l';

@Component({
  selector: 'page-consonantes',
  templateUrl: 'consonantes.html'
})
export class ConsonantesPage {

  constructor(public navCtrl: NavController) {
  }
  goToM(params){
    if (!params) params = {};
    this.navCtrl.push(MPage);
  }goToMa(params){
    if (!params) params = {};
    this.navCtrl.push(MaPage);
  }goToP(params){
    if (!params) params = {};
    this.navCtrl.push(PPage);
  }goToN(params){
    if (!params) params = {};
    this.navCtrl.push(NPage);
  }goToL(params){
    if (!params) params = {};
    this.navCtrl.push(LPage);
  }
}
