import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-las-vocales4',
  templateUrl: 'las-vocales4.html'
})
export class LasVocales4Page {

  constructor(public navCtrl: NavController) {
  }
  
}
