import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-p',
  templateUrl: 'p.html'
})
export class PPage {

  constructor(public navCtrl: NavController) {
  }
  
}
