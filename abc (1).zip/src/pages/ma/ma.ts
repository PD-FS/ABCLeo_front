import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-ma',
  templateUrl: 'ma.html'
})
export class MaPage {

  constructor(public navCtrl: NavController) {
  }
  
}
