import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-silabas-trabadas',
  templateUrl: 'silabas-trabadas.html'
})
export class SilabasTrabadasPage {

  constructor(public navCtrl: NavController) {
  }
  
}
